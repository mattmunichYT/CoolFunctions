tag @p add morph
summon warden ~ ~ ~ {Tags:["morphmob"],PersistenceRequired:true}
team join noCollisions.COOLFUNCTIONS @e[tag=morphmob]
execute as @e[tag=morphmob] store result score @s morphMobHealth run attribute @s minecraft:max_health get
function coolfunctions:morph/mobhealthtoplayer
tellraw @p[tag=morph] [{"text":"C","color":"#D5D576","bold":true},{"text":"o","color":"#AED991","bold":true},{"text":"o","color":"#86DEAB","bold":true},{"text":"l","color":"#73E0B8","bold":true},{"text":"F","color":"#5FE2C5","bold":true},{"text":"u","color":"#66E6AE","bold":true},{"text":"n","color":"#6DEA96","bold":true},{"text":"c","color":"#73ED7F","bold":true},{"text":"t","color":"#7AF167","bold":true},{"text":"i","color":"#7AF167","bold":true},{"text":"o","color":"#7AF167","bold":true},{"text":"n","color":"#7AF167","bold":true},{"text":"s","color":"#7AF167","bold":true},{"text":" >> ","bold":true,"color":"dark_gray"}, "§aMorphed to a §5warden"]